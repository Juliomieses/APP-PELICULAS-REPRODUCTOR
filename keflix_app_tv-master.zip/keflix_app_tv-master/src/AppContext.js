//Imports
import React from "react";

//Vars
export const AppContext = React.createContext();